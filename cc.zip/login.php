<?php
include ("config/config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Kamils Web-Jukebox</title>
<?php
include ("inc/header.php"); ?>
<script type="text/javascript" src="login_js.php"></script>

</head>
<body>

<div id="form-ct"></div>

</body>
</html>
